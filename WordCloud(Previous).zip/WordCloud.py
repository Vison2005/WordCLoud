import os
import sys
import shutil
from functools import partial

from PyQt5.QtWidgets import (QApplication, QMainWindow, QPushButton, QVBoxLayout, QHBoxLayout,
                             QWidget, QLabel, QFileDialog, QComboBox, QSlider, QSizePolicy,
                             QScrollArea)
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtCore import Qt
from wordcloud import WordCloud
import jieba
import imageio

class WordCloudApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

        # 初始化必要的路径变量
        self.image_path = ''  # 默认不指定
        self.font_path = ''   # 默认不指定
        self.text_file_path = ''  # 默认不指定

    def initUI(self):
        self.setWindowTitle('Word Cloud Generator')  # 窗口标题
        self.setGeometry(100, 100, 1800, 800)        # 窗口大小

        # ------------------ 主布局（水平） ------------------
        main_layout = QHBoxLayout()

        # =============== 左侧布局（红色区域） ===============
        self.left_widget = QWidget()
        self.left_widget.setStyleSheet("background-color: #FF4B4B;")  # 示意红色
        left_layout = QVBoxLayout(self.left_widget)
        left_layout.setContentsMargins(5, 5, 5, 5)
        left_layout.setSpacing(5)

        # 1) 左上方三个黄色按钮（水平布局）
        button_layout = QHBoxLayout()
        self.btn_select_image = QPushButton('选择缩略图(底图)')
        self.btn_select_image.setStyleSheet("background-color: yellow;")
        self.btn_select_image.clicked.connect(lambda: self.select_file('image'))
        button_layout.addWidget(self.btn_select_image)

        self.btn_select_text = QPushButton('选择文本文件')
        self.btn_select_text.setStyleSheet("background-color: yellow;")
        self.btn_select_text.clicked.connect(lambda: self.select_file('text'))
        button_layout.addWidget(self.btn_select_text)

        self.btn_select_font = QPushButton('选择字体')
        self.btn_select_font.setStyleSheet("background-color: yellow;")
        self.btn_select_font.clicked.connect(lambda: self.select_file('font'))
        button_layout.addWidget(self.btn_select_font)

        left_layout.addLayout(button_layout)

        # 2) 左侧用 QScrollArea + QVBoxLayout 来显示缩略图列表
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        scroll_content = QWidget()
        self.thumbnail_layout = QVBoxLayout(scroll_content)
        self.thumbnail_layout.setContentsMargins(5, 5, 5, 5)
        self.thumbnail_layout.setSpacing(5)

        # 如果不存在 ./thumbnail 文件夹，就创建
        if not os.path.exists('./thumbnail'):
            os.mkdir('./thumbnail')

        # 加载 ./thumbnail 下所有图片并显示
        for fname in os.listdir('./thumbnail'):
            # 你可以根据需求修改图片格式的判断
            if fname.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
                path = os.path.join('./thumbnail', fname)
                pixmap = QPixmap(path)
                # 缩放一下，避免过大
                pixmap = pixmap.scaled(200, 150, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                label = QLabel()
                label.setPixmap(pixmap)
                label.setAlignment(Qt.AlignCenter)
                self.thumbnail_layout.addWidget(label)

        self.scroll_area.setWidget(scroll_content)
        left_layout.addWidget(self.scroll_area)

        # =============== 中间布局（黑色区域） ===============
        self.center_widget = QWidget()
        self.center_widget.setStyleSheet("background-color: black;")  # 示意黑色
        center_layout = QVBoxLayout(self.center_widget)
        center_layout.setContentsMargins(5, 5, 5, 5)
        center_layout.setSpacing(5)

        # 中间上方：显示词云图
        self.wordcloud_label = QLabel('词云图将显示在这里')
        self.wordcloud_label.setAlignment(Qt.AlignCenter)
        self.wordcloud_label.setStyleSheet("background-color: #333333; color: white;")
        self.wordcloud_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        center_layout.addWidget(self.wordcloud_label)

        # 中间下方：两个蓝色按钮（水平布局）
        center_button_layout = QHBoxLayout()
        self.btn_update = QPushButton('更新词云图')
        self.btn_update.setStyleSheet("background-color: blue; color: white;")
        self.btn_update.clicked.connect(self.update_wordcloud)
        center_button_layout.addWidget(self.btn_update)

        self.btn_export = QPushButton('保存到导出文件夹')
        self.btn_export.setStyleSheet("background-color: blue; color: white;")
        self.btn_export.clicked.connect(self.export_wordcloud)
        center_button_layout.addWidget(self.btn_export)

        center_layout.addLayout(center_button_layout)

        # =============== 右侧布局 ===============
        self.right_widget = QWidget()
        right_layout = QVBoxLayout(self.right_widget)
        right_layout.setContentsMargins(5, 5, 5, 5)
        right_layout.setSpacing(20)

        # 右侧上方（绿色区域）——选择字体
        font_widget = QWidget()
        font_widget.setStyleSheet("background-color: #00FF00;")  # 示意绿色
        font_layout = QVBoxLayout(font_widget)
        font_layout.setContentsMargins(5, 5, 5, 5)
        font_layout.setSpacing(5)

        self.font_label = QLabel('选择字体:')
        font_layout.addWidget(self.font_label)

        self.font_combobox = QComboBox()
        # 这里可以加入更多字体名称
        self.font_combobox.addItems(['SimHei', 'Arial', 'Times New Roman'])
        font_layout.addWidget(self.font_combobox)

        right_layout.addWidget(font_widget)

        # 右侧下方（紫色区域）——选择风格
        style_widget = QWidget()
        style_widget.setStyleSheet("background-color: magenta;")  # 示意紫色
        style_layout = QVBoxLayout(style_widget)
        style_layout.setContentsMargins(5, 5, 5, 5)
        style_layout.setSpacing(5)

        self.style_label = QLabel('选择风格:')
        style_layout.addWidget(self.style_label)

        self.style_combobox = QComboBox()
        self.style_combobox.addItems(['Default', 'Style 1', 'Style 2'])
        style_layout.addWidget(self.style_combobox)

        right_layout.addWidget(style_widget)

        # 将左、中、右三部分加到 main_layout
        main_layout.addWidget(self.left_widget, 2)    # 左侧略小
        main_layout.addWidget(self.center_widget, 5)  # 中间大
        main_layout.addWidget(self.right_widget, 2)   # 右侧略小

        # 中心部件
        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

    def select_file(self, file_type):
        """ 根据类型选择文件并保存到相应的路径变量。 """
        file_path, _ = QFileDialog.getOpenFileName(self, f"选择{file_type.capitalize()}文件")
        if file_path:
            if file_type == 'image':
                self.image_path = file_path
            elif file_type == 'font':
                self.font_path = file_path
            elif file_type == 'text':
                self.text_file_path = file_path

    def update_wordcloud(self):
        """ 更新并显示词云图 """
        # 如果没有选择必要的文件，做简单的判断
        if not self.text_file_path:
            self.wordcloud_label.setText("请先选择文本文件！")
            return

        if not self.image_path:
            self.wordcloud_label.setText("请先选择底图(缩略图)！")
            return

        # 如果用户没选字体，就用 ComboBox 的值；如果选了文件，则用文件
        if not self.font_path:
            # 尝试从 ComboBox 的值加载系统字体
            selected_font_name = self.font_combobox.currentText()
            # 这里要保证你的系统确实有这个字体，可根据实际情况修改
            # 常见中文字体：SimHei 对应 C:/Windows/Fonts/simhei.ttf（Windows下）
            # 或者你可以自定义一个映射字典来找真正的 ttf 路径
            if selected_font_name == 'SimHei':
                self.font_path = 'C:/Windows/Fonts/simhei.ttf'
            elif selected_font_name == 'Arial':
                self.font_path = 'C:/Windows/Fonts/arial.ttf'
            else:
                self.font_path = 'C:/Windows/Fonts/times.ttf'

        # 生成词云
        self.generate_wordcloud()
        # 显示词云
        self.display_wordcloud()

    def generate_wordcloud(self):
        """ 词云生成逻辑 """
        # 读取文本
        with open(self.text_file_path, 'r', encoding='utf-8') as f:
            s = f.read()

        # 去掉常见标点
        rp_str = ['，', '。', '！', '？', '、', '：', '；', '（', '）', '《', '》',
                  '“', '”', '‘', '’', '【', '】', '—', '…', '·', '～', ' ']
        for i in rp_str:
            s = s.replace(i, '')
        s = ''.join(s.split())

        # 加载用户自定义词典（若有）
        jieba.load_userdict(self.text_file_path)
        words = jieba.lcut(s)

        # 简单地把文本文件内容当做停用词表
        stopwords_list = []
        with open(self.text_file_path, 'r', encoding='utf-8') as f_stop:
            stopwords = f_stop.read()
            stopwords_list = list(stopwords)

        words_dict = {}
        for w in words:
            if len(w) == 1:
                continue
            if w not in stopwords_list:
                words_dict[w] = words_dict.get(w, 0) + 1

        words_list = list(words_dict.items())
        words_list.sort(key=lambda x: x[1], reverse=True)
        words_count = dict(words_list)

        # 保存词频统计到文件
        with open('./wordcloudCount.txt', 'w', encoding='utf-8') as f_out:
            for k, v in words_list:
                f_out.write('{:<8}{:>2}\n'.format(k, v))

        # 生成词云图
        mask_image = imageio.imread(self.image_path)
        w = WordCloud(
            font_path=self.font_path,
            background_color='white',
            width=1000,
            height=800,
            max_words=1000,
            mask=mask_image
        )
        w.generate_from_frequencies(words_count)
        w.to_file('./wordcloud.png')

    def display_wordcloud(self):
        """ 在中间区域显示生成好的词云图 """
        if os.path.exists('thumbnail/wordcloud.png'):
            pixmap = QPixmap('thumbnail/wordcloud.png')
            self.wordcloud_label.setPixmap(pixmap.scaled(
                self.wordcloud_label.width(),
                self.wordcloud_label.height(),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            ))
        else:
            self.wordcloud_label.setText("未找到词云图文件，请先点击更新词云图。")

    def export_wordcloud(self):
        """ 保存生成好的词云图到 ./export 文件夹 """
        if not os.path.exists('thumbnail/wordcloud.png'):
            self.wordcloud_label.setText("还没有生成词云图，无法导出。")
            return

        # 创建 export 文件夹
        if not os.path.exists('./export'):
            os.mkdir('./export')

        # 将 wordcloud.png 复制到 ./export 文件夹
        export_path = os.path.join('./export', 'wordcloud_export.png')
        shutil.copy('thumbnail/wordcloud.png', export_path)
        self.wordcloud_label.setText(f"已导出到: {export_path}")

def main():
    app = QApplication(sys.argv)
    ex = WordCloudApp()
    ex.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
