import os
import sys
import shutil
import random
from functools import partial

from PyQt5.QtWidgets import (QApplication, QMainWindow, QPushButton, QVBoxLayout, QHBoxLayout,
                             QWidget, QLabel, QFileDialog, QComboBox, QListWidget, QScrollArea,
                             QSizePolicy, QColorDialog)
from PyQt5.QtGui import QPixmap, QIcon, QColor
from PyQt5.QtCore import Qt, QSize

from wordcloud import WordCloud
import jieba
import imageio

class WordCloudApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('词云生成器')
        self.setGeometry(100, 100, 1800, 800)
        # 设置图标（如果存在图标文件）
        if os.path.exists('WordCloud.png'):
            self.setWindowIcon(QIcon('WordCloud.png'))

        # 开启拖拽支持
        self.setAcceptDrops(True)

        # 初始化选项路径
        self.image_path = ''       # 当前选中的底图路径
        self.font_path = ''        # 当前选中的字体路径
        self.text_file_path = ''   # 当前选中的文本文件路径

        # 颜色相关：基础颜色、相近颜色列表、对比颜色列表
        self.base_text_color = '#000000'  # 默认基础颜色：黑色
        self.similar_text_colors = []     # 存储添加的相近颜色
        self.contrast_text_colors = []    # 存储添加的对比颜色
        self.bg_color = '#ffffff'         # 默认背景颜色：白色

        # 主布局（水平分布：左、中、右）
        main_layout = QHBoxLayout()

        # ==================== 左侧区域（缩略图 + 3 个按钮） ====================
        self.left_widget = QWidget()
        self.left_widget.setStyleSheet("background-color: grey;")  # 背景灰色
        left_layout = QVBoxLayout(self.left_widget)
        left_layout.setContentsMargins(5, 5, 5, 5)
        left_layout.setSpacing(1)

        # 1) 顶部三个按钮（水平布局）
        top_buttons_layout = QHBoxLayout()
        # a) 选择底图
        self.btn_select_image = QPushButton('选择缩略图(底图)')
        self.btn_select_image.setStyleSheet("background-color: white;")
        self.btn_select_image.clicked.connect(lambda: self.select_file('image'))
        top_buttons_layout.addWidget(self.btn_select_image)
        # b) 选择文本文件
        self.btn_select_text = QPushButton('选择文本文件')
        self.btn_select_text.setStyleSheet("background-color: white;")
        self.btn_select_text.clicked.connect(lambda: self.select_file('text'))
        top_buttons_layout.addWidget(self.btn_select_text)
        # c) 选择字体
        self.btn_select_font = QPushButton('选择字体')
        self.btn_select_font.setStyleSheet("background-color: white;")
        self.btn_select_font.clicked.connect(lambda: self.select_file('font'))
        top_buttons_layout.addWidget(self.btn_select_font)
        left_layout.addLayout(top_buttons_layout)

        # 2) 缩略图滚动区域
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        scroll_content = QWidget()
        self.thumbnail_layout = QVBoxLayout(scroll_content)
        self.thumbnail_layout.setContentsMargins(5, 5, 5, 5)
        self.thumbnail_layout.setSpacing(0)

        # 若 ./thumbnail 不存在则创建
        if not os.path.exists('./thumbnail'):
            os.mkdir('./thumbnail')

        # 加载 ./thumbnail 下所有图片，按钮+图标形式显示
        for fname in os.listdir('./thumbnail'):
            if fname.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
                path = os.path.join('./thumbnail', fname)
                btn_thumb = QPushButton()
                btn_thumb.setText(fname)
                btn_thumb.setIcon(QIcon(path))
                btn_thumb.setIconSize(QSize(180, 120))
                btn_thumb.setStyleSheet("background-color: white;")
                # 点击后设置为底图，并自动更新词云（若已选文本）
                btn_thumb.clicked.connect(partial(self.thumbnail_clicked, path))
                self.thumbnail_layout.addWidget(btn_thumb)

        self.scroll_area.setWidget(scroll_content)
        left_layout.addWidget(self.scroll_area)

        # ==================== 中间区域（词云显示 + 3 个按钮） ====================
        self.center_widget = QWidget()
        self.center_widget.setStyleSheet("background-color: white;")
        center_layout = QVBoxLayout(self.center_widget)
        center_layout.setContentsMargins(5, 5, 5, 5)
        center_layout.setSpacing(5)

        # 1) 词云显示区域
        self.wordcloud_label = QLabel('词云图将显示在这里')
        self.wordcloud_label.setAlignment(Qt.AlignCenter)
        self.wordcloud_label.setStyleSheet("background-color: #4e5181; color: white;")
        self.wordcloud_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        center_layout.addWidget(self.wordcloud_label)

        # 2) 底部三个按钮（水平布局）
        center_button_layout = QHBoxLayout()
        # a) 更新词云图
        self.btn_update = QPushButton('更新词云图')
        self.btn_update.setStyleSheet("background-color: grey; color: white;")
        self.btn_update.clicked.connect(self.update_wordcloud)
        center_button_layout.addWidget(self.btn_update)
        # b) 导出到同目录下文件夹
        self.btn_export = QPushButton('导出到同目录下文件夹')
        self.btn_export.setStyleSheet("background-color: grey; color: white;")
        self.btn_export.clicked.connect(self.export_wordcloud)
        center_button_layout.addWidget(self.btn_export)
        # c) 另存为
        self.btn_save_as = QPushButton('另存为')
        self.btn_save_as.setStyleSheet("background-color: grey; color: white;")
        self.btn_save_as.clicked.connect(self.save_as_wordcloud)
        center_button_layout.addWidget(self.btn_save_as)
        center_layout.addLayout(center_button_layout)

        # ==================== 右侧区域（上方：字体下拉 + 颜色设置，下方：文本列表） ====================
        self.right_widget = QWidget()
        right_layout = QVBoxLayout(self.right_widget)
        right_layout.setContentsMargins(5, 5, 5, 5)
        right_layout.setSpacing(5)

        # 1) 上方区域：字体下拉及颜色设置
        font_widget = QWidget()
        font_layout = QVBoxLayout(font_widget)
        font_layout.setContentsMargins(5, 5, 5, 5)
        font_layout.setSpacing(5)
        # 字体下拉框
        self.font_combobox = QComboBox()
        self.font_combobox.addItems(['SimHei', 'Arial', 'Times New Roman'])
        font_layout.addWidget(self.font_combobox)

        # --- 选择基础字体颜色 ---
        base_color_layout = QHBoxLayout()
        self.btn_base_text_color = QPushButton("选择基础字体颜色")
        self.btn_base_text_color.clicked.connect(self.choose_base_text_color)
        base_color_layout.addWidget(self.btn_base_text_color)
        self.lbl_base_color = QLabel()
        self.lbl_base_color.setFixedSize(20, 20)
        self.lbl_base_color.setStyleSheet("background-color: {};".format(self.base_text_color))
        base_color_layout.addWidget(self.lbl_base_color)
        font_layout.addLayout(base_color_layout)

        # --- 添加相近颜色 ---
        similar_color_layout = QHBoxLayout()
        self.btn_add_similar = QPushButton("添加相近颜色")
        self.btn_add_similar.clicked.connect(self.choose_similar_text_color)
        similar_color_layout.addWidget(self.btn_add_similar)
        self.similar_color_container = QWidget()
        self.similar_color_container_layout = QHBoxLayout(self.similar_color_container)
        self.similar_color_container_layout.setContentsMargins(0,0,0,0)
        self.similar_color_container_layout.setSpacing(2)
        similar_color_layout.addWidget(self.similar_color_container)
        font_layout.addLayout(similar_color_layout)

        # --- 添加对比颜色 ---
        contrast_color_layout = QHBoxLayout()
        self.btn_add_contrast = QPushButton("添加对比颜色")
        self.btn_add_contrast.clicked.connect(self.choose_contrast_text_color)
        contrast_color_layout.addWidget(self.btn_add_contrast)
        self.contrast_color_container = QWidget()
        self.contrast_color_container_layout = QHBoxLayout(self.contrast_color_container)
        self.contrast_color_container_layout.setContentsMargins(0,0,0,0)
        self.contrast_color_container_layout.setSpacing(2)
        contrast_color_layout.addWidget(self.contrast_color_container)
        font_layout.addLayout(contrast_color_layout)

        # --- 选择背景颜色 ---
        bg_color_layout = QHBoxLayout()
        self.btn_bg_color = QPushButton("选择背景颜色")
        self.btn_bg_color.clicked.connect(self.choose_bg_color)
        bg_color_layout.addWidget(self.btn_bg_color)
        self.lbl_bg_color = QLabel()
        self.lbl_bg_color.setFixedSize(20, 20)
        self.lbl_bg_color.setStyleSheet("background-color: {};".format(self.bg_color))
        bg_color_layout.addWidget(self.lbl_bg_color)
        font_layout.addLayout(bg_color_layout)

        right_layout.addWidget(font_widget)

        # 2) 下方区域：文本文件列表
        text_list_widget = QWidget()
        text_list_layout = QVBoxLayout(text_list_widget)
        text_list_layout.setContentsMargins(5, 5, 5, 5)
        text_list_layout.setSpacing(5)
        self.text_list = QListWidget()
        text_list_layout.addWidget(self.text_list)
        right_layout.addWidget(text_list_widget)
        self.right_widget.setLayout(right_layout)

        # 将左、中、右区域加入主布局
        main_layout.addWidget(self.left_widget, 3)
        main_layout.addWidget(self.center_widget, 10)
        main_layout.addWidget(self.right_widget, 2)

        # 设置主窗口中心部件
        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        # 初始化：加载文本文件列表（./texts 文件夹）
        self.load_text_files()

    # ==================== 拖拽支持 ====================
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            file_path = url.toLocalFile().strip()
            if file_path.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
                self.image_path = file_path
                if self.text_file_path:
                    self.update_wordcloud()
            elif file_path.lower().endswith('.txt'):
                self.text_file_path = file_path
                if self.image_path:
                    self.update_wordcloud()
            elif file_path.lower().endswith('.ttf'):
                self.font_path = file_path
                if self.text_file_path and self.image_path:
                    self.update_wordcloud()

    # ==================== 左侧缩略图点击 ====================
    def thumbnail_clicked(self, path):
        self.image_path = path
        print(f"选中的底图: {path}")
        if self.text_file_path:
            self.update_wordcloud()

    # ==================== 文本文件列表 ====================
    def load_text_files(self):
        if not os.path.exists('./texts'):
            os.mkdir('./texts')
        for fname in os.listdir('./texts'):
            if fname.lower().endswith('.txt'):
                self.text_list.addItem(fname)
        self.text_list.currentTextChanged.connect(self.on_text_file_selected)

    def on_text_file_selected(self, filename):
        self.text_file_path = os.path.join('./texts', filename)
        print(f"选中的文本文件: {self.text_file_path}")
        if self.image_path:
            self.update_wordcloud()

    # ==================== “选择文件”按钮 ====================
    def select_file(self, file_type):
        file_path, _ = QFileDialog.getOpenFileName(self, f"选择{file_type.capitalize()}文件")
        if file_path:
            if file_type == 'image':
                self.image_path = file_path
                if self.text_file_path:
                    self.update_wordcloud()
            elif file_type == 'font':
                self.font_path = file_path
                if self.text_file_path and self.image_path:
                    self.update_wordcloud()
            elif file_type == 'text':
                self.text_file_path = file_path
                if self.image_path:
                    self.update_wordcloud()

    # ==================== 颜色选择相关 ====================
    def choose_base_text_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self.base_text_color = color.name()
            self.lbl_base_color.setStyleSheet("background-color: {};".format(self.base_text_color))
            if self.text_file_path and self.image_path:
                self.update_wordcloud()

    def choose_similar_text_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self.similar_text_colors.append(color.name())
            # 新建一个小标签显示该颜色
            lbl = QLabel()
            lbl.setFixedSize(20, 20)
            lbl.setStyleSheet("background-color: {};".format(color.name()))
            self.similar_color_container_layout.addWidget(lbl)
            if self.text_file_path and self.image_path:
                self.update_wordcloud()

    def choose_contrast_text_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self.contrast_text_colors.append(color.name())
            lbl = QLabel()
            lbl.setFixedSize(20, 20)
            lbl.setStyleSheet("background-color: {};".format(color.name()))
            self.contrast_color_container_layout.addWidget(lbl)
            if self.text_file_path and self.image_path:
                self.update_wordcloud()

    def choose_bg_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self.bg_color = color.name()
            self.lbl_bg_color.setStyleSheet("background-color: {};".format(self.bg_color))
            if self.text_file_path and self.image_path:
                self.update_wordcloud()

    # ==================== 自定义多颜色函数 ====================
    def multi_color_func(self, word, font_size, position, orientation, random_state=None, **kwargs):
        # 合并所有可用颜色：基础、相近、对比
        colors = []
        if self.base_text_color:
            colors.append(self.base_text_color)
        colors.extend(self.similar_text_colors)
        colors.extend(self.contrast_text_colors)
        if colors:
            return random.choice(colors)
        else:
            return "#000000"

    # ==================== 生成 & 显示词云图 ====================
    def update_wordcloud(self):
        if not self.text_file_path:
            self.wordcloud_label.setText("请先选择文本文件！")
            return
        if not self.image_path:
            self.wordcloud_label.setText("请先选择底图(缩略图)！")
            return

        if not self.font_path:
            selected_font_name = self.font_combobox.currentText()
            if selected_font_name == 'SimHei':
                self.font_path = 'C:/Windows/Fonts/simhei.ttf'
            elif selected_font_name == 'Arial':
                self.font_path = 'C:/Windows/Fonts/arial.ttf'
            else:
                self.font_path = 'C:/Windows/Fonts/times.ttf'

        self.generate_wordcloud()
        self.display_wordcloud()

    def generate_wordcloud(self):
        with open(self.text_file_path, 'r', encoding='utf-8') as f:
            s = f.read()

        rp_str = ['，', '。', '！', '？', '、', '：', '；', '（', '）', '《', '》',
                  '“', '”', '‘', '’', '【', '】', '—', '…', '·', '～', ' ']
        for i in rp_str:
            s = s.replace(i, '')
        s = ''.join(s.split())

        jieba.load_userdict(self.text_file_path)
        words = jieba.lcut(s)

        with open(self.text_file_path, 'r', encoding='utf-8') as f_stop:
            stopwords = f_stop.read()
            stopwords_list = list(stopwords)

        words_dict = {}
        for w in words:
            if len(w) == 1:
                continue
            if w not in stopwords_list:
                words_dict[w] = words_dict.get(w, 0) + 1

        words_list = sorted(words_dict.items(), key=lambda x: x[1], reverse=True)
        words_count = dict(words_list)

        with open('./wordcloudCount.txt', 'w', encoding='utf-8') as f_out:
            for k, v in words_list:
                f_out.write('{:<8}{:>2}\n'.format(k, v))

        # 采用更大分辨率与 scale 参数提高图像清晰度
        mask_image = imageio.imread(self.image_path)
        w = WordCloud(
            font_path=self.font_path,
            background_color=self.bg_color,
            width=2000,
            height=1600,
            scale=2,
            max_words=1000,
            mask=mask_image,
            color_func=self.multi_color_func
        )
        w.generate_from_frequencies(words_count)
        w.to_file('./wordcloud.png')

    def display_wordcloud(self):
        if os.path.exists('./wordcloud.png'):
            pixmap = QPixmap('./wordcloud.png')
            self.wordcloud_label.setPixmap(pixmap.scaled(
                self.wordcloud_label.width(),
                self.wordcloud_label.height(),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            ))
        else:
            self.wordcloud_label.setText("未找到词云图，请先点击更新词云图。")

    # ==================== 导出 & 另存为 ====================
    def export_wordcloud(self):
        if not os.path.exists('./wordcloud.png'):
            self.wordcloud_label.setText("还没有生成词云图，无法导出。")
            return
        if not os.path.exists('./export'):
            os.mkdir('./export')
        export_path = os.path.join('./export', 'wordcloud_export.png')
        shutil.copy('./wordcloud.png', export_path)
        self.wordcloud_label.setText(f"已导出到: {export_path}")

    def save_as_wordcloud(self):
        if not os.path.exists('./wordcloud.png'):
            self.wordcloud_label.setText("还没有生成词云图，无法另存为。")
            return
        save_path, _ = QFileDialog.getSaveFileName(
            self, "另存为", "wordcloud.png",
            "PNG Files (*.png);;All Files (*)"
        )
        if save_path:
            shutil.copy('./wordcloud.png', save_path)
            self.wordcloud_label.setText(f"已另存为: {save_path}")

def main():
    app = QApplication(sys.argv)
    ex = WordCloudApp()
    ex.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
