import os
import sys
from PyQt5.QtWidgets import (QApplication, QMainWindow, QPushButton, QVBoxLayout, QHBoxLayout, QWidget, QLabel,
                             QFileDialog, QComboBox, QSlider, QSizePolicy)
from PyQt5.QtGui import QPixmap, QImage
from PyQt5.QtCore import Qt
from wordcloud import WordCloud
import jieba
import imageio
from functools import partial

class WordCloudApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Word Cloud Generator') # 窗口标题
        self.setGeometry(100, 100, 1800, 800)      # 窗口大小, 左上角坐标, 宽, 高, 单位:像素

        # 主要布局,左边:中间:右边=1:5:1
        main_layout = QHBoxLayout()


        # 左侧面板
        self.left_panel = QVBoxLayout()
        self.thumbnail_label = QLabel('缩略图列表')
        #设置为灰色背景,可滚动
        self.thumbnail_label.setStyleSheet("background-color: gray;")
        self.thumbnail_label.setAlignment(Qt.AlignCenter)
        self.thumbnail_label.setScaledContents(True)
        self.thumbnail_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.thumbnail_label.setMinimumSize(600, 800)
        self.thumbnail_label.setMaximumSize(600, 800)
        #创建缩略图文件夹,如果不存在,则新建文件夹
        if not os.path.exists('./thumbnail'):
            os.mkdir('./thumbnail')
        #加载缩略图文件夹中的所有图片
        for i in os.listdir('./thumbnail'):
            if i.endswith('.jpg'):
                thumbnail = QLabel()
                thumbnail.setPixmap(QPixmap('./thumbnail/'+i))
                thumbnail.setAlignment(Qt.AlignCenter)
                self.left_panel.addWidget(thumbnail)

        # 中间面板
        self.left_panel.addWidget(self.thumbnail_label)
        main_layout.addLayout(self.left_panel, 1)

        # Middle panel for word cloud display
        self.middle_panel = QVBoxLayout()
        self.wordcloud_label = QLabel('Word Cloud will be displayed here')
        self.wordcloud_label.setAlignment(Qt.AlignCenter)
        self.middle_panel.addWidget(self.wordcloud_label)
        main_layout.addLayout(self.middle_panel, 2)

        # Right panel for controls
        self.right_panel = QVBoxLayout()

        # Style selection
        self.style_label = QLabel('Select Style:')
        self.style_combobox = QComboBox()
        self.style_combobox.addItems(['Default', 'Style 1', 'Style 2'])
        self.right_panel.addWidget(self.style_label)
        self.right_panel.addWidget(self.style_combobox)

        # Font selection
        self.font_label = QLabel('Select Font:')
        self.font_combobox = QComboBox()
        self.font_combobox.addItems(['SimHei', 'Arial', 'Times New Roman'])
        self.right_panel.addWidget(self.font_label)
        self.right_panel.addWidget(self.font_combobox)

        # Update button
        self.update_button = QPushButton('Update Word Cloud')
        self.update_button.clicked.connect(self.update_wordcloud)
        self.right_panel.addWidget(self.update_button)

        main_layout.addLayout(self.right_panel, 1)

        # Top left buttons
        self.top_left_buttons = QHBoxLayout()
        self.image_button = QPushButton('Select Image')
        self.image_button.clicked.connect(lambda: self.select_file('image'))
        self.top_left_buttons.addWidget(self.image_button)

        self.font_button = QPushButton('Select Font')
        self.font_button.clicked.connect(lambda: self.select_file('font'))
        self.top_left_buttons.addWidget(self.font_button)

        self.text_file_button = QPushButton('Select Text File')
        self.text_file_button.clicked.connect(lambda: self.select_file('text'))
        self.top_left_buttons.addWidget(self.text_file_button)

        self.update_button = QPushButton('Update Word Cloud')
        self.update_button.clicked.connect(self.update_wordcloud)

        main_layout.addLayout(self.top_left_buttons)

        # Set main layout
        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        # Initialize variables
        self.image_path = 'thumbnail/China.jpg'
        self.font_path = 'C:/Windows/Fonts/simhei.ttf'
        self.text_file_path = './wordcloud.txt'

    def select_file(self, file_type):
        file_path, _ = QFileDialog.getOpenFileName(self, f"Select {file_type.capitalize()} File")
        if file_path:
            if file_type == 'image':
                self.image_path = file_path
            elif file_type == 'font':
                self.font_path = file_path
            elif file_type == 'text':
                self.text_file_path = file_path

    def update_wordcloud(self):
        # Generate word cloud
        self.generate_wordcloud()
        # Display word cloud
        self.display_wordcloud()

    def generate_wordcloud(self):
        # Read and process text
        s = open(self.text_file_path, 'r', encoding='utf-8').read()
        rp_str = ['，', '。', '！', '？', '、', '：', '；', '（', '）', '《', '》', '“', '”', '‘', '’', '【', '】', '—', '…', '·', '～', ' ']
        for i in rp_str:
            s = s.replace(i, '')
        s = ''.join(s.split())
        jieba.load_userdict(self.text_file_path)
        words = jieba.lcut(s)

        stopwords = open(self.text_file_path, 'r', encoding='utf-8').read()
        stopwords_list = list(stopwords)

        words_dict = {}
        for i in words:
            if len(i) == 1:
                continue
            if i not in stopwords_list:
                words_dict[i] = words_dict.get(i, 0) + 1

        words_list = list(words_dict.items())
        words_list.sort(key=lambda x: x[1], reverse=True)
        words_count = dict(words_list)

        file = open('./wordcloudCount.txt', 'w', encoding='utf-8')
        for i in range(len(words_list)):
            k, v = words_list[i]
            file.write('{:<8}{:>2}\n'.format(k, v))
        file.close()

        # Generate word cloud image
        w = WordCloud(
            font_path=self.font_path,
            background_color='white',
            width=1000,
            height=800,
            max_words=1000,
            mask=imageio.imread(self.image_path)
        )
        w.generate_from_frequencies(words_count)
        w.to_file('./wordcloud.png')

    def display_wordcloud(self):
        pixmap = QPixmap('thumbnail/wordcloud.png')
        self.wordcloud_label.setPixmap(pixmap)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = WordCloudApp()
    ex.show()
    sys.exit(app.exec_())
