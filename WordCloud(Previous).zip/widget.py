from PyQt5.QtGui import QPixmap
from imageio import imread
import wordcloud
import jieba

# s = open('./wordcloud.txt', 'r', encoding='utf-8').read()
# rp_str = ['，', '。', '！', '？', '、', '：', '；', '（', '）', '《', '》', '“', '”', '‘', '’', '【', '】', '—', '…', '·', '～', ' ']
# for i in rp_str:
#     s = s.replace(i, '')
# s = ''.join(s.split())
# jieba.load_userdict('./wordcloud.txt')
# words = jieba.lcut(s)
def get_text():
    txt = open("./wordcloud.txt", "r", encoding='utf-8').read()
    rp_str = ['，', '。', '！', '？', '、', '：', '；', '（', '）', '《', '》', '“', '”', '‘', '’', '【', '】', '—', '…', '·', '～','']
    for i in rp_str:
        txt = txt.replace(i, '')
    txt = ''.join(txt.split())
    jieba.load_userdict('./wordcloud.txt')
    return txt
words = jieba.lcut(get_text())

# stopwords = open('./wordcloud.txt', 'r', encoding='utf-8').read()
# stopwords_list = list(stopwords)
#
# words_dict = {}
# for i in words:
#     if len(i) == 1:
#         continue
#     if i not in stopwords_list:
#         words_dict[i]=words_dict.get(i,0)+1
#
# words_list = list(words_dict.items())
# words_list.sort(key=lambda x:x[1],reverse=True)
# words_count = dict(words_list)
# print(words_count)
#
# file = open('./wordcloudCount.txt', 'w', encoding='utf-8')
# for i in range(len(words_list)):
#     k,v = words_list[i]
#     file.write('{:<8}{:>2}\n'.format(k,v))
# file.close()

def get_stopwords():
    stopwords = open('./wordcloud.txt', 'r', encoding='utf-8').read()
    stopwords_list = list(stopwords)
    return stopwords_list
def get_words_dict():
    stopwords_list = get_stopwords()
    words_dict = {}
    for i in words:
        if len(i) == 1:
            continue
        if i not in stopwords_list:
            words_dict[i]=words_dict.get(i,0)+1
    return words_dict
def get_words_list():
    words_dict = get_words_dict()
    words_list = list(words_dict.items())
    words_list.sort(key=lambda x:x[1],reverse=True)
    return words_list
def get_words_count():
    words_list = get_words_list()
    words_count = dict(words_list)
    return words_count
def get_words_count_txt():
    words_list = get_words_list()
    file = open('./wordcloudCount.txt', 'w', encoding='utf-8')
    for i in range(len(words_list)):
        k,v = words_list[i]
        file.write('{:<8}{:>2}\n'.format(k,v))
    file.close()

# CountTXT = open('./wordcloudCount.txt', 'r', encoding='utf-8').read()
# w = wordcloud.WordCloud(
#     font_path='C:/Windows/Fonts/simhei.ttf',
#     background_color='white',
#     width=1000,
#     height=800,
#     max_words=1000,
#     mask=imread('./China.jpg')
# )
# w.generate(CountTXT)
# w.to_file('./wordcloud.png')
def get_wordcloud():
    CountTXT = open('./wordcloudCount.txt', 'r', encoding='utf-8').read()
    w = wordcloud.WordCloud(
        font_path='C:/Windows/Fonts/simhei.ttf',
        background_color='white',
        width=1000,
        height=800,
        max_words=1000,
        mask=imread('./China.jpg')
    )
    w.generate(CountTXT)
    w.to_file('./wordcloud.png')

#使用PyQt5进行窗口制作
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QVBoxLayout, QWidget
import os
class WordCloudApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.initUI()
    def initUI(self):
        self.setWindowTitle('Word Cloud Generator') # 窗口标题
        self.setGeometry(100, 100, 1200, 800)      # 窗口大小, 左上角坐标, 宽, 高, 单位:像素
        # 主要布局,左边:中间:右边=1:5:1
        main_layout = QVBoxLayout()
        # 左侧面板
        self.left_panel = QVBoxLayout()
        self.thumbnail_label = QLabel('缩略图将在这里显示')
        #在当前目录创建缩略图文件夹,如果不存在,则新建文件夹
        if not os.path.exists('./thumbnail'):
            os.mkdir('./thumbnail')
        #加载缩略图文件夹中的所有图片
        for i in os.listdir('./thumbnail'):
            if i.endswith('.jpg'):
                self.thumbnail_label.setPixmap(QPixmap('./thumbnail/'+i))
        self.left_panel.addWidget(self.thumbnail_label)
        main_layout.addLayout(self.left_panel, 1)   # 左侧面板占1/6
        #中间面板
        self.middle_panel = QVBoxLayout()
        self.wordcloud_label = QLabel('词云将在这里显示')


if __name__ == '__main__':
    get_words_count_txt()
    get_wordcloud()
