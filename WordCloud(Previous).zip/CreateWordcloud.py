from imageio import imread
import wordcloud
CountTXT = open('./wordcloudCount.txt', 'r', encoding='utf-8').read()
w = wordcloud.WordCloud(
    font_path='C:/Windows/Fonts/simhei.ttf',
    background_color='white',
    width=1000,
    height=800,
    max_words=1000,
    mask=imread('./China.jpg')
)
w.generate(CountTXT)
w.to_file('./wordcloud.png')