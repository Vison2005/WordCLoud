import os
import sys
import shutil
from functools import partial

from PyQt5.QtWidgets import (QApplication, QMainWindow, QPushButton, QVBoxLayout, QHBoxLayout,
                             QWidget, QLabel, QFileDialog, QComboBox, QListWidget, QScrollArea,
                             QSizePolicy)
from PyQt5.QtGui import QPixmap, QIcon, QImage
from PyQt5.QtCore import Qt, QSize
from wordcloud import WordCloud
import jieba
import imageio

class WordCloudApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('词云生成器')
        self.setGeometry(100, 100, 1800, 800)
        #设置图标
        self.setWindowIcon(QIcon('WordCloud.png'))

        # 初始化变量
        self.image_path = ''       # 当前选中的底图路径
        self.font_path = ''        # 当前选中的字体路径
        self.text_file_path = ''   # 当前选中的文本文件路径

        # 主布局（水平分布：左、中、右）
        main_layout = QHBoxLayout()

        # ==================== 左侧：红色区域（缩略图 + 3 个黄色按钮） ====================
        self.left_widget = QWidget()
        self.left_widget.setStyleSheet("background-color: grey;")  #暗灰色
        left_layout = QVBoxLayout(self.left_widget)
        left_layout.setContentsMargins(5, 5, 5, 5)
        left_layout.setSpacing(1)

        # 1) 顶部三个黄色按钮（水平布局）
        top_buttons_layout = QHBoxLayout()
        # a) 选择缩略图(底图)
        self.btn_select_image = QPushButton('选择缩略图(底图)')
        self.btn_select_image.setStyleSheet("background-color: white;")
        self.btn_select_image.clicked.connect(lambda: self.select_file('image'))
        top_buttons_layout.addWidget(self.btn_select_image)

        # b) 选择文本文件
        self.btn_select_text = QPushButton('选择文本文件')
        self.btn_select_text.setStyleSheet("background-color: white;")
        self.btn_select_text.clicked.connect(lambda: self.select_file('text'))
        top_buttons_layout.addWidget(self.btn_select_text)

        # c) 选择字体
        self.btn_select_font = QPushButton('选择字体')
        self.btn_select_font.setStyleSheet("background-color: white;")
        self.btn_select_font.clicked.connect(lambda: self.select_file('font'))
        top_buttons_layout.addWidget(self.btn_select_font)

        left_layout.addLayout(top_buttons_layout)

        # 2) 缩略图滚动区域
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        scroll_content = QWidget()
        self.thumbnail_layout = QVBoxLayout(scroll_content)
        self.thumbnail_layout.setContentsMargins(5, 5, 5, 5)    # 调整图片之间的间距
        self.thumbnail_layout.setSpacing(0)  # 调整图片之间的间距

        # 若 ./thumbnail 不存在则创建
        if not os.path.exists('./thumbnail'):
            os.mkdir('./thumbnail')

        # 加载 ./thumbnail 下所有图片，使用按钮的方式可点击选择
        for fname in os.listdir('./thumbnail'):
            if fname.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp')):
                path = os.path.join('./thumbnail', fname)

                # 用按钮 + icon 的方式显示缩略图
                btn_thumb = QPushButton()
                btn_thumb.setText(fname)  # 或者不显示文字，仅图标
                btn_thumb.setIcon(QIcon(path))
                btn_thumb.setIconSize(QSize(180, 120))  # 缩略图大小
                btn_thumb.setStyleSheet("background-color: white;")

                # 点击该按钮后，将此图片路径设置为 self.image_path
                btn_thumb.clicked.connect(partial(self.thumbnail_clicked, path))

                self.thumbnail_layout.addWidget(btn_thumb)

        self.scroll_area.setWidget(scroll_content)
        left_layout.addWidget(self.scroll_area)

        # ==================== 中间：区域（显示词云图 + 3 个按钮） ====================
        self.center_widget = QWidget()
        self.center_widget.setStyleSheet("background-color: white;")
        center_layout = QVBoxLayout(self.center_widget)
        center_layout.setContentsMargins(5, 5, 5, 5)
        center_layout.setSpacing(5)

        # 1) 词云显示区域
        self.wordcloud_label = QLabel('词云图将显示在这里')
        self.wordcloud_label.setAlignment(Qt.AlignCenter)
        self.wordcloud_label.setStyleSheet("background-color: #4e5181; color: white;")
        self.wordcloud_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        center_layout.addWidget(self.wordcloud_label)

        # 2) 底部三个蓝色按钮（水平布局）
        center_button_layout = QHBoxLayout()

        # a) 更新词云图
        self.btn_update = QPushButton('更新词云图')
        self.btn_update.setStyleSheet("background-color: grey; color: white;")
        self.btn_update.clicked.connect(self.update_wordcloud)
        center_button_layout.addWidget(self.btn_update)

        # b) 导出到同目录下文件夹（./export）
        self.btn_export = QPushButton('导出到同目录下文件夹')
        self.btn_export.setStyleSheet("background-color: grey; color: white;")
        self.btn_export.clicked.connect(self.export_wordcloud)
        center_button_layout.addWidget(self.btn_export)

        # c) 另存为（可指定路径）
        self.btn_save_as = QPushButton('另存为')
        self.btn_save_as.setStyleSheet("background-color: grey; color: white;")
        self.btn_save_as.clicked.connect(self.save_as_wordcloud)
        center_button_layout.addWidget(self.btn_save_as)

        center_layout.addLayout(center_button_layout)

        # ==================== 右侧：上方（仅一个字体下拉），下方（文本文件列表） ====================
        self.right_widget = QWidget()
        right_layout = QVBoxLayout(self.right_widget)
        right_layout.setContentsMargins(5, 5, 5, 5)
        right_layout.setSpacing(5)

        # 1) 上方绿色区域 - 仅保留一个字体下拉框
        font_widget = QWidget()
        font_widget.setStyleSheet("background-color: #white;")  # 白色示意
        font_widget.setFixedHeight(30)  # 缩小高度
        font_layout = QVBoxLayout(font_widget)
        font_layout.setContentsMargins(5, 5, 5, 5)
        font_layout.setSpacing(5)

        self.font_combobox = QComboBox()
        # 这里可添加更多常见字体
        self.font_combobox.addItems(['SimHei', 'Arial', 'Times New Roman'])
        font_layout.addWidget(self.font_combobox)

        right_layout.addWidget(font_widget)

        # 2) 下方紫色区域 - 文本文件列表
        text_list_widget = QWidget()
        text_list_widget.setStyleSheet("background-color: white;")  # 白色示意
        text_list_layout = QVBoxLayout(text_list_widget)
        text_list_layout.setContentsMargins(5, 5, 5, 5)
        text_list_layout.setSpacing(5)

        self.text_list = QListWidget()
        text_list_layout.addWidget(self.text_list)

        right_layout.addWidget(text_list_widget)

        # 将右侧布局应用
        self.right_widget.setLayout(right_layout)

        # 将左、中、右添加到主布局
        main_layout.addWidget(self.left_widget, 3)
        main_layout.addWidget(self.center_widget, 10)
        main_layout.addWidget(self.right_widget, 1)

        # 设置中心部件
        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)

        # 初始化：加载文本文件列表
        self.load_text_files()

    # ---------------------- 左侧缩略图点击事件 ----------------------
    def thumbnail_clicked(self, path):
        """当点击左侧缩略图按钮时，将该图片设为底图。"""
        self.image_path = path
        # 也可以在这里做一些高亮或提示，示例仅简单打印
        print(f"选中的底图: {path}")

    # ---------------------- 加载文本文件列表 ----------------------
    def load_text_files(self):
        """在右侧的文本列表中，显示 ./texts 文件夹内所有 .txt 文件。"""
        # 如果没有 ./texts 文件夹则创建
        if not os.path.exists('./texts'):
            os.mkdir('./texts')

        # 列出所有 .txt 文件
        for fname in os.listdir('./texts'):
            if fname.lower().endswith('.txt'):
                self.text_list.addItem(fname)

        # 选中列表某一项时，更新 self.text_file_path
        self.text_list.currentTextChanged.connect(self.on_text_file_selected)

    def on_text_file_selected(self, filename):
        """当列表中选中某个文本文件时，更新 self.text_file_path。"""
        self.text_file_path = os.path.join('./texts', filename)
        print(f"选中的文本文件: {self.text_file_path}")

    # ---------------------- 3 个黄色按钮的文件选择 ----------------------
    def select_file(self, file_type):
        """ 通过文件对话框选择文件 """
        file_path, _ = QFileDialog.getOpenFileName(self, f"选择{file_type.capitalize()}文件")
        if file_path:
            if file_type == 'image':
                self.image_path = file_path
            elif file_type == 'font':
                self.font_path = file_path
            elif file_type == 'text':
                self.text_file_path = file_path

    # ---------------------- 中间功能按钮：更新词云图、导出、另存为 ----------------------
    def update_wordcloud(self):
        """ 更新并显示词云图 """
        # 判断是否有文本文件和底图
        if not self.text_file_path:
            self.wordcloud_label.setText("请先选择文本文件！")
            return
        if not self.image_path:
            self.wordcloud_label.setText("请先选择底图(缩略图)！")
            return

        # 若未通过“选择字体”按钮选字体，则用下拉框的字体名
        if not self.font_path:
            selected_font_name = self.font_combobox.currentText()
            # 简单映射常见字体到 Windows 的路径，可根据自身系统情况修改
            if selected_font_name == 'SimHei':
                self.font_path = 'C:/Windows/Fonts/simhei.ttf'
            elif selected_font_name == 'Arial':
                self.font_path = 'C:/Windows/Fonts/arial.ttf'
            else:
                self.font_path = 'C:/Windows/Fonts/times.ttf'

        # 生成并显示词云
        self.generate_wordcloud()
        self.display_wordcloud()

    def generate_wordcloud(self):
        """ 词云生成逻辑 """
        with open(self.text_file_path, 'r', encoding='utf-8') as f:
            s = f.read()

        # 去除常见标点
        rp_str = ['，', '。', '！', '？', '、', '：', '；', '（', '）', '《', '》',
                  '“', '”', '‘', '’', '【', '】', '—', '…', '·', '～', ' ']
        for i in rp_str:
            s = s.replace(i, '')
        s = ''.join(s.split())

        # 加载用户词典（若需要）
        jieba.load_userdict(self.text_file_path)
        words = jieba.lcut(s)

        # 将文本文件本身作为停用词
        with open(self.text_file_path, 'r', encoding='utf-8') as f_stop:
            stopwords = f_stop.read()
            stopwords_list = list(stopwords)

        words_dict = {}
        for w in words:
            if len(w) == 1:
                continue
            if w not in stopwords_list:
                words_dict[w] = words_dict.get(w, 0) + 1

        words_list = sorted(words_dict.items(), key=lambda x: x[1], reverse=True)
        words_count = dict(words_list)

        # 写入词频统计
        with open('./wordcloudCount.txt', 'w', encoding='utf-8') as f_out:
            for k, v in words_list:
                f_out.write('{:<8}{:>2}\n'.format(k, v))

        # 生成词云
        mask_image = imageio.imread(self.image_path)
        w = WordCloud(
            font_path=self.font_path,
            background_color='white',
            width=1000,
            height=800,
            max_words=1000,
            mask=mask_image
        )
        w.generate_from_frequencies(words_count)
        w.to_file('./wordcloud.png')

    def display_wordcloud(self):
        """ 在中间区域显示生成好的词云图 """
        if os.path.exists('./wordcloud.png'):
            pixmap = QPixmap('./wordcloud.png')
            self.wordcloud_label.setPixmap(pixmap.scaled(
                self.wordcloud_label.width(),
                self.wordcloud_label.height(),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            ))
        else:
            self.wordcloud_label.setText("未找到词云图，请先点击更新词云图。")

    def export_wordcloud(self):
        """ 导出词云图到同目录下 ./export 文件夹 """
        if not os.path.exists('./wordcloud.png'):
            self.wordcloud_label.setText("还没有生成词云图，无法导出。")
            return

        if not os.path.exists('./export'):
            os.mkdir('./export')

        export_path = os.path.join('./export', 'wordcloud_export.png')
        shutil.copy('./wordcloud.png', export_path)
        self.wordcloud_label.setText(f"已导出到: {export_path}")

    def save_as_wordcloud(self):
        """ 另存为：用户可自行选择保存路径 """
        if not os.path.exists('./wordcloud.png'):
            self.wordcloud_label.setText("还没有生成词云图，无法另存为。")
            return

        save_path, _ = QFileDialog.getSaveFileName(self, "另存为", "wordcloud.png",
                                                   "PNG Files (*.png);;All Files (*)")
        if save_path:
            shutil.copy('./wordcloud.png', save_path)
            self.wordcloud_label.setText(f"已另存为: {save_path}")

def main():
    app = QApplication(sys.argv)
    ex = WordCloudApp()
    ex.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main()
