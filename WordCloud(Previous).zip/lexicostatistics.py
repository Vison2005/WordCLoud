import jieba

s = open('./wordcloud.txt', 'r', encoding='utf-8').read()
rp_str = ['，', '。', '！', '？', '、', '：', '；', '（', '）', '《', '》', '“', '”', '‘', '’', '【', '】', '—', '…', '·', '～', ' ']
for i in rp_str:
    s = s.replace(i, '')
s = ''.join(s.split())
jieba.load_userdict('./wordcloud.txt')
words = jieba.lcut(s)

stopwords = open('./wordcloud.txt', 'r', encoding='utf-8').read()
stopwords_list = list(stopwords)

words_dict = {}
for i in words:
    if len(i) == 1:
        continue
    if i not in stopwords_list:
        words_dict[i]=words_dict.get(i,0)+1

words_list = list(words_dict.items())
words_list.sort(key=lambda x:x[1],reverse=True)
words_count = dict(words_list)
print(words_count)

file = open('./wordcloudCount.txt', 'w', encoding='utf-8')
for i in range(len(words_list)):
    k,v = words_list[i]
    file.write('{:<8}{:>2}\n'.format(k,v))
file.close()